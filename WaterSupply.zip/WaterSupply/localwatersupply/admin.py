from django.contrib import admin
from .models import destination

admin.site.register(destination)

