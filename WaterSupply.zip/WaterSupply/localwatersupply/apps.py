from django.apps import AppConfig


class LocalwatersupplyConfig(AppConfig):
    name = 'localwatersupply'
